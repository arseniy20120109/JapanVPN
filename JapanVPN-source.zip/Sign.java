import com.android.apksig.ApkSigner;

import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sign {
    public static void main(String[] args) throws Exception {
        KeyStore ks = KeyStore.getInstance("JKS");
        ks.load(new FileInputStream(args[0]), args[2].toCharArray());
        PrivateKey key = (PrivateKey) ks.getKey(args[1], args[2].toCharArray());
        List<X509Certificate> certs = new ArrayList<X509Certificate>();
        for (Certificate c : ks.getCertificateChain(args[1])) {
            certs.add((X509Certificate) c);
        }
        ApkSigner.SignerConfig config = new ApkSigner.SignerConfig.Builder(args[1], key, certs).build();
        new ApkSigner.Builder(Collections.singletonList(config))
                .setInputApk(new File(args[3]))
                .setOutputApk(new File(args[4]))
                .setMinSdkVersion(24)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .build()
                .sign();
        System.out.println("Signed: " + args[4]);
    }
}
