#!/bin/sh
set -e
cd /storage/emulated/0/JapanV-Build/project
SDK=/data/data/cat.narezany.margycode/cache/tmp/japanvpn/sdk
OUT=/storage/emulated/0/Download/Japan_v.apk

rm -rf build
mkdir -p build/classes build/dex build/com

echo "[1/6] aapt2 compile resources"
qemu-x86_64 $SDK/aapt2 compile --dir res -o build/compiled.zip

echo "[2/6] aapt2 link manifest + resources"
qemu-x86_64 $SDK/aapt2 link -o build/base.apk -I $SDK/android-framework.jar \
  --manifest AndroidManifest.xml -R build/compiled.zip --java build \
  --auto-add-overlay --min-sdk-version 24 --target-sdk-version 34 \
  --version-code 31 --version-name 1.0

echo "[3/6] javac"
javac -source 8 -target 8 -encoding UTF-8 -classpath $SDK/android-all.jar \
  -d build/classes $(find src build/com -name '*.java')

echo "[4/6] d8 (classes.dex)"
java -cp $SDK/r8.jar com.android.tools.r8.D8 \
  --lib $SDK/android-all.jar --min-api 24 --output build/dex \
  $(find build/classes -name '*.class')

echo "[5/6] package dex + native libraries (aligned)"
python3 pack.py

echo "[6/6] sign"
javac -cp $SDK/apksig.jar -d build Sign.java
java --add-exports java.base/sun.security.x509=ALL-UNNAMED \
  --add-exports java.base/sun.security.util=ALL-UNNAMED \
  --add-exports java.base/sun.security.pkcs=ALL-UNNAMED \
  -cp build:$SDK/apksig.jar Sign japan.jks japan japan123 build/unsigned.apk build/Japan_v.apk
cp build/Japan_v.apk "$OUT"
chmod 644 "$OUT"
ls -lh "$OUT"
echo "DONE: $OUT"
