import zipfile, struct, os

BASE = 'build/base.apk'
OUT = 'build/unsigned.apk'


def aligned_extra(data_offset, alignment):
    """Extra field that pads the local header so data starts aligned."""
    pad = (-data_offset) % alignment
    if pad < 4:
        pad += alignment
    return struct.pack('<HH', 0xD935, pad - 4) + b'\x00' * (pad - 4)


def add(zout, name, data, compress=zipfile.ZIP_STORED, alignment=0):
    zi = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    zi.compress_type = compress
    zi.external_attr = 0o644 << 16
    zi.create_system = 0
    if alignment:
        pos = zout.fp.tell()
        base = pos + 30 + len(name.encode('utf-8'))
        zi.extra = aligned_extra(base, alignment)
    zout.writestr(zi, data)


with zipfile.ZipFile(BASE) as zin, zipfile.ZipFile(OUT, 'w') as zout:
    for item in zin.infolist():
        name = item.filename
        data = zin.read(name)
        if name == 'resources.arsc':
            add(zout, name, data, zipfile.ZIP_STORED, 4)
        else:
            add(zout, name, data, item.compress_type, 0)

    # classes.dex must be stored and 4-byte aligned.
    add(zout, 'classes.dex', open('build/dex/classes.dex', 'rb').read(),
        zipfile.ZIP_STORED, 4)

    # Compress native libraries: Android extracts them at install time and
    # no page alignment is required for compressed .so files.
    for root, dirs, files in os.walk('jni/lib'):
        for f in sorted(files):
            p = os.path.join(root, f)
            arc = 'lib/' + os.path.relpath(p, 'jni/lib').replace(os.sep, '/')
            add(zout, arc, open(p, 'rb').read(), zipfile.ZIP_DEFLATED, 0)

print('packaged', os.path.getsize(OUT), 'bytes')
