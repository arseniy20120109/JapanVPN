package com.japanvpn.v;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;

final class ThemeHelper {
    static final int[] ACCENTS = {
            0xFFF06292, 0xFFE53935, 0xFFAB47BC, 0xFF42A5F5, 0xFF26A69A, 0xFFFFB300
    };

    private ThemeHelper() { }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("japanvpn", Context.MODE_PRIVATE);
    }

    static int accent(Context c) {
        SharedPreferences p = prefs(c);
        if (!p.getBoolean("theme_v4", false)) {
            p.edit().putBoolean("theme_v4", true).putInt("accent", ACCENTS[0]).apply();
            return ACCENTS[0];
        }
        return p.getInt("accent", ACCENTS[0]);
    }

    static String lang(Context c) {
        String l = prefs(c).getString("lang", "ru");
        return "en".equals(l) ? "en" : "ru";
    }

    static int light(int color) {
        return blend(color, Color.WHITE, 0.38f);
    }

    static int darker(int color) {
        return blend(color, Color.BLACK, 0.42f);
    }

    static int deep(int color) {
        return blend(color, Color.BLACK, 0.68f);
    }

    static int surface(int color) {
        return blend(color, 0xFF0B0609, 0.88f);
    }

    static int surfaceAlt(int color) {
        return blend(color, 0xFF0B0609, 0.78f);
    }

    private static int blend(int color, int other, float ratio) {
        int r = Math.round(Color.red(color) * (1 - ratio) + Color.red(other) * ratio);
        int g = Math.round(Color.green(color) * (1 - ratio) + Color.green(other) * ratio);
        int b = Math.round(Color.blue(color) * (1 - ratio) + Color.blue(other) * ratio);
        return Color.rgb(r, g, b);
    }

    /** Solid accent-tinted background — no picture wallpaper. */
    static Drawable wallpaperDrawable(Context c) {
        int a = accent(c);
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{surfaceAlt(a), surface(a)});
    }
}
