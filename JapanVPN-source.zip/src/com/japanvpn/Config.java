package com.japanvpn.v;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Parses an AmneziaWG / WARP .conf file into Android VPN + userspace settings. */
final class Config {
    File file;
    String name;
    String privateKeyBase64;
    final List<String[]> addresses = new ArrayList<String[]>(); // {ip, prefix}
    final List<String> dns = new ArrayList<String>();
    int mtu = 1280;
    final Map<String, String> amnezia = new LinkedHashMap<String, String>();
    String publicKeyBase64;
    final List<String[]> allowedIps = new ArrayList<String[]>();
    String endpointHost;
    int endpointPort = 4500;
    int keepalive = 0;
    String settings;

    private Config(File file) {
        this.file = file;
        this.name = file.getName();
    }

    static Config parse(File file) throws Exception {
        Config c = new Config(file);
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
        try {
            String section = "";
            String line;
            while ((line = reader.readLine()) != null) {
                int comment = line.indexOf('#');
                if (comment >= 0) line = line.substring(0, comment);
                line = line.trim();
                if (line.length() == 0) continue;
                if (line.startsWith("[")) {
                    section = line.equalsIgnoreCase("[Interface]") ? "iface"
                            : (line.equalsIgnoreCase("[Peer]") ? "peer" : "");
                    continue;
                }
                int eq = line.indexOf('=');
                if (eq < 0) continue;
                String key = line.substring(0, eq).trim().toLowerCase(Locale.ENGLISH);
                String value = line.substring(eq + 1).trim();
                if ("iface".equals(section)) {
                    c.parseInterfaceLine(key, value);
                } else if ("peer".equals(section)) {
                    c.parsePeerLine(key, value);
                }
            }
        } finally {
            reader.close();
        }
        c.buildSettings();
        return c;
    }

    private void parseInterfaceLine(String key, String value) {
        if (key.equals("privatekey")) {
            privateKeyBase64 = value;
        } else if (key.equals("address")) {
            for (String part : value.split(",")) addNetwork(addresses, part.trim());
        } else if (key.equals("dns")) {
            for (String part : value.split(",")) {
                String s = part.trim();
                if (s.length() > 0) dns.add(s);
            }
        } else if (key.equals("mtu")) {
            try { mtu = Integer.parseInt(value); } catch (NumberFormatException ignored) { }
        } else if (key.equals("listenport")) {
            try { amnezia.put("listen_port", String.valueOf(Integer.parseInt(value))); } catch (NumberFormatException ignored) { }
        } else if (key.equals("jc")) {
            amnezia.put("jc", value);
        } else if (key.equals("jmin")) {
            amnezia.put("jmin", value);
        } else if (key.equals("jmax")) {
            amnezia.put("jmax", value);
        } else if (key.equals("s1") || key.equals("s2") || key.equals("s3") || key.equals("s4")) {
            try { amnezia.put(key, String.valueOf(Integer.parseInt(value))); } catch (NumberFormatException ignored) { }
        } else if (key.equals("h1") || key.equals("h2") || key.equals("h3") || key.equals("h4")) {
            amnezia.put(key, value);
        } else if (key.equals("i1") || key.equals("i2") || key.equals("i3") || key.equals("i4") || key.equals("i5")) {
            amnezia.put(key, value);
        } else if (key.equals("headerprotectionkey")) {
            amnezia.put("header_protection_key", toHex(Base64.getDecoder().decode(value)));
        } else if (key.equals("contentpaddingaddition")) {
            amnezia.put("content_padding_addition", value);
        } else if (key.equals("rekeyaftertime")) {
            amnezia.put("rekey_after_time", value);
        } else if (key.equals("rekeytimeout")) {
            amnezia.put("rekey_timeout", value);
        } else if (key.equals("rejectaftertime")) {
            amnezia.put("reject_after_time", value);
        } else if (key.equals("keepalivetimeout")) {
            amnezia.put("keepalive_timeout", value);
        } else if (key.equals("maxhandshakeattempts")) {
            amnezia.put("max_handshake_attempts", value);
        } else if (key.equals("randomtrailers") || key.equals("disablecookies")) {
            String v = value.toLowerCase(Locale.ENGLISH);
            amnezia.put(key.equals("randomtrailers") ? "random_trailers" : "disable_cookies",
                    (v.equals("on") || v.equals("1") || v.equals("true") || v.equals("yes")) ? "1" : "0");
        }
    }

    private void parsePeerLine(String key, String value) {
        if (key.equals("publickey")) {
            publicKeyBase64 = value;
        } else if (key.equals("allowedips")) {
            for (String part : value.split(",")) addNetwork(allowedIps, part.trim());
        } else if (key.equals("endpoint")) {
            int colon = value.lastIndexOf(':');
            if (colon > 0) {
                endpointHost = value.substring(0, colon);
                if (endpointHost.startsWith("[") && endpointHost.endsWith("]"))
                    endpointHost = endpointHost.substring(1, endpointHost.length() - 1);
                try { endpointPort = Integer.parseInt(value.substring(colon + 1)); } catch (NumberFormatException ignored) { }
            } else {
                endpointHost = value;
            }
        } else if (key.equals("persistentkeepalive")) {
            try { keepalive = Integer.parseInt(value); } catch (NumberFormatException ignored) { }
        }
    }

    private static void addNetwork(List<String[]> target, String value) {
        if (value.length() == 0) return;
        String ip = value;
        String prefix;
        int slash = value.indexOf('/');
        if (slash > 0) {
            ip = value.substring(0, slash);
            prefix = value.substring(slash + 1);
        } else {
            prefix = ip.contains(":") ? "128" : "32";
        }
        target.add(new String[]{ip, prefix});
    }

    private void buildSettings() throws Exception {
        if (privateKeyBase64 == null || publicKeyBase64 == null)
            throw new IllegalArgumentException("В конфиге нет PrivateKey/PublicKey");
        StringBuilder sb = new StringBuilder();
        sb.append("private_key=").append(toHex(privateKeyBase64)).append('\n');
        for (Map.Entry<String, String> e : amnezia.entrySet())
            sb.append(e.getKey()).append('=').append(e.getValue()).append('\n');
        sb.append("replace_peers=true\n");
        sb.append("public_key=").append(toHex(publicKeyBase64)).append('\n');
        for (String[] n : allowedIps)
            sb.append("allowed_ip=").append(n[0]).append('/').append(n[1]).append('\n');
        if (endpointHost != null) {
            String host = endpointHost;
            try {
                host = InetAddress.getByName(endpointHost).getHostAddress();
            } catch (Exception ignored) {
                // Let the userspace library resolve the hostname itself.
            }
            String formatted = host.contains(":") ? "[" + host + "]" : host;
            sb.append("endpoint=").append(formatted).append(':').append(endpointPort).append('\n');
        }
        if (keepalive > 0)
            sb.append("persistent_keepalive_interval=").append(keepalive).append('\n');
        settings = sb.toString();
    }

    private static String toHex(String base64) {
        return toHex(Base64.getDecoder().decode(base64.replace("\n", "").replace(" ", "")));
    }

    private static String toHex(byte[] bytes) {
        char[] chars = "0123456789abcdef".toCharArray();
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(chars[(b >> 4) & 0xf]).append(chars[b & 0xf]);
        }
        return sb.toString();
    }

    String shortName() {
        return name.endsWith(".conf") ? name.substring(0, name.length() - 5) : name;
    }
}
