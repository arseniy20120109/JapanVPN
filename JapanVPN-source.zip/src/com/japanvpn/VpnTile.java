package com.japanvpn.v;

import android.content.Intent;
import android.graphics.drawable.Icon;
import android.net.VpnService;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

/** Quick Settings tile: pull down the shade to turn JapanVPN on or off. */
public final class VpnTile extends TileService {
    @Override
    public void onTileAdded() {
        super.onTileAdded();
        refresh();
    }

    @Override
    public void onStartListening() {
        super.onStartListening();
        refresh();
    }

    @Override
    public void onClick() {
        if (VpnController.handle >= 0) {
            VpnController.stop(this);
        } else {
            Config cfg = VpnController.selected != null ? VpnController.selected
                    : VpnController.firstConfig(this);
            if (cfg == null) {
                Toast.makeText(this, getString(R.string.toast_no_server), Toast.LENGTH_LONG).show();
                refresh();
                return;
            }
            Intent prepare;
            try {
                prepare = VpnService.prepare(this);
            } catch (Exception e) {
                prepare = null;
            }
            if (prepare != null) {
                Intent open = new Intent(this, MainActivity.class);
                open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                open.putExtra("auto_connect", true);
                try {
                    startActivityAndCollapse(open);
                } catch (Exception ignored) { }
                refresh();
                return;
            }
            VpnController.start(this, cfg);
        }
        refresh();
    }

    private void refresh() {
        Tile tile = getQsTile();
        if (tile == null) return;
        boolean on = VpnController.handle >= 0;
        tile.setIcon(Icon.createWithResource(this, R.drawable.ic_white));
        tile.setLabel(getString(R.string.app_name));
        tile.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.setContentDescription(getString(on ? R.string.status_connected : R.string.status_stopped));
        tile.updateTile();
    }
}
