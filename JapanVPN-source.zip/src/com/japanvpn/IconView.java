package com.japanvpn.v;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Clean, filled vector icons drawn with paths — no emoji or image assets. */
final class IconView extends View {
    static final int GLOBE = 1;
    static final int FOLDER = 2;
    static final int HOME = 3;
    static final int SETTINGS = 4;
    static final int POWER = 5;
    static final int CHECK = 6;
    static final int PENCIL = 7;
    static final int TRASH = 8;
    static final int PLUS = 9;
    static final int UPLOAD = 10;
    static final int PALETTE = 11;
    static final int IMAGE = 12;
    static final int LANGUAGE = 13;
    static final int SHIELD = 14;
    static final int BACK = 15;
    static final int PAINT = 16;
    static final int PALETTE_BRUSH = 17;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int kind;

    IconView(Context c, int kind, int color, int sizeDp) {
        super(c);
        this.kind = kind;
        paint.setColor(color);
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        int size = Math.round(getResources().getDisplayMetrics().density * sizeDp);
        setLayoutParams(new android.view.ViewGroup.LayoutParams(size, size));
    }

    void setColor(int color) {
        paint.setColor(color);
        invalidate();
    }

    private void stroke(float w) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(w);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float s = Math.min(getWidth(), getHeight()) / 2f;
        c.save();
        c.translate(getWidth() / 2f, getHeight() / 2f);
        Path p = new Path();
        paint.setStyle(Paint.Style.FILL);

        switch (kind) {
            case GLOBE:
                stroke(s * 0.18f);
                c.drawCircle(0, 0, s * 0.78f, paint);
                c.drawLine(0, -s * 0.78f, 0, s * 0.78f, paint);
                c.drawLine(-s * 0.78f, 0, s * 0.78f, 0, paint);
                p.moveTo(0, -s * 0.78f);
                p.quadTo(s * 0.62f, 0, 0, s * 0.78f);
                p.quadTo(-s * 0.62f, 0, 0, -s * 0.78f);
                c.drawPath(p, paint);
                break;
            case FOLDER:
                p.moveTo(-s * 0.82f, -s * 0.52f);
                p.lineTo(-s * 0.24f, -s * 0.52f);
                p.lineTo(-s * 0.02f, -s * 0.28f);
                p.lineTo(s * 0.82f, -s * 0.28f);
                p.lineTo(s * 0.82f, s * 0.62f);
                p.lineTo(-s * 0.82f, s * 0.62f);
                p.close();
                c.drawPath(p, paint);
                break;
            case HOME:
                p.setFillType(Path.FillType.EVEN_ODD);
                p.moveTo(0, -s * 0.86f);
                p.lineTo(s * 0.86f, -s * 0.04f);
                p.lineTo(s * 0.62f, -s * 0.04f);
                p.lineTo(s * 0.62f, s * 0.78f);
                p.lineTo(-s * 0.62f, s * 0.78f);
                p.lineTo(-s * 0.62f, -s * 0.04f);
                p.lineTo(-s * 0.86f, -s * 0.04f);
                p.close();
                p.addRect(-s * 0.18f, s * 0.16f, s * 0.18f, s * 0.78f, Path.Direction.CW);
                c.drawPath(p, paint);
                c.drawRect(s * 0.38f, -s * 0.68f, s * 0.6f, -s * 0.28f, paint);
                break;
            case SETTINGS:
                // Cogwheel with a hole in the middle.
                p.setFillType(Path.FillType.EVEN_ODD);
                p.addCircle(0, 0, s * 0.6f, Path.Direction.CW);
                p.addCircle(0, 0, s * 0.22f, Path.Direction.CW);
                c.drawPath(p, paint);
                stroke(s * 0.26f);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    float x1 = (float) (Math.cos(a) * s * 0.62f);
                    float y1 = (float) (Math.sin(a) * s * 0.62f);
                    float x2 = (float) (Math.cos(a) * s * 0.86f);
                    float y2 = (float) (Math.sin(a) * s * 0.86f);
                    c.drawLine(x1, y1, x2, y2, paint);
                }
                break;
            case POWER:
                stroke(s * 0.24f);
                c.drawArc(-s * 0.66f, -s * 0.66f, s * 1.32f, s * 1.32f, -55, 290, false, paint);
                c.drawLine(0, -s * 0.82f, 0, 0, paint);
                break;
            case CHECK:
                stroke(s * 0.26f);
                p.moveTo(-s * 0.6f, 0);
                p.lineTo(-s * 0.22f, s * 0.44f);
                p.lineTo(s * 0.66f, -s * 0.5f);
                c.drawPath(p, paint);
                break;
            case PENCIL:
                p.moveTo(-s * 0.62f, s * 0.5f);
                p.lineTo(-s * 0.78f, s * 0.86f);
                p.lineTo(-s * 0.42f, s * 0.7f);
                p.lineTo(s * 0.62f, -s * 0.36f);
                p.lineTo(s * 0.34f, -s * 0.64f);
                p.close();
                c.drawPath(p, paint);
                break;
            case TRASH:
                p.moveTo(-s * 0.72f, -s * 0.52f);
                p.lineTo(s * 0.72f, -s * 0.52f);
                p.lineTo(s * 0.72f, -s * 0.3f);
                p.lineTo(-s * 0.72f, -s * 0.3f);
                p.close();
                c.drawPath(p, paint);
                p.reset();
                p.moveTo(-s * 0.56f, -s * 0.22f);
                p.lineTo(s * 0.56f, -s * 0.22f);
                p.lineTo(s * 0.42f, s * 0.78f);
                p.lineTo(-s * 0.42f, s * 0.78f);
                p.close();
                c.drawPath(p, paint);
                break;
            case PLUS:
                stroke(s * 0.26f);
                c.drawLine(-s * 0.66f, 0, s * 0.66f, 0, paint);
                c.drawLine(0, -s * 0.66f, 0, s * 0.66f, paint);
                break;
            case UPLOAD:
                stroke(s * 0.22f);
                c.drawLine(0, s * 0.62f, 0, -s * 0.42f, paint);
                p.moveTo(-s * 0.44f, -s * 0.02f);
                p.lineTo(0, -s * 0.5f);
                p.lineTo(s * 0.44f, -s * 0.02f);
                c.drawPath(p, paint);
                c.drawLine(-s * 0.7f, s * 0.7f, s * 0.7f, s * 0.7f, paint);
                break;
            case PALETTE:
                stroke(s * 0.20f);
                c.drawCircle(0, 0, s * 0.78f, paint);
                paint.setStyle(Paint.Style.FILL);
                c.drawCircle(-s * 0.28f, -s * 0.26f, s * 0.1f, paint);
                c.drawCircle(s * 0.28f, -s * 0.26f, s * 0.1f, paint);
                c.drawCircle(0, s * 0.36f, s * 0.1f, paint);
                break;
            case IMAGE:
                stroke(s * 0.18f);
                c.drawRect(-s * 0.8f, -s * 0.66f, s * 0.8f, s * 0.66f, paint);
                c.drawCircle(-s * 0.36f, -s * 0.26f, s * 0.20f, paint);
                p.moveTo(-s * 0.72f, s * 0.46f);
                p.lineTo(-s * 0.1f, -s * 0.22f);
                p.lineTo(s * 0.72f, s * 0.56f);
                c.drawPath(p, paint);
                break;
            case LANGUAGE:
                stroke(s * 0.20f);
                c.drawCircle(0, 0, s * 0.75f, paint);
                c.drawLine(-s * 0.75f, 0, s * 0.75f, 0, paint);
                p.moveTo(0, -s * 0.75f);
                p.quadTo(s * 0.55f, 0, 0, s * 0.75f);
                p.quadTo(-s * 0.55f, 0, 0, -s * 0.75f);
                c.drawPath(p, paint);
                break;
            case SHIELD:
                p.moveTo(0, -s * 0.84f);
                p.lineTo(s * 0.7f, -s * 0.5f);
                p.lineTo(s * 0.58f, s * 0.36f);
                p.lineTo(0, s * 0.84f);
                p.lineTo(-s * 0.58f, s * 0.36f);
                p.lineTo(-s * 0.7f, -s * 0.5f);
                p.close();
                c.drawPath(p, paint);
                break;
            case BACK:
                stroke(s * 0.26f);
                p.moveTo(s * 0.38f, -s * 0.62f);
                p.lineTo(-s * 0.34f, 0);
                p.lineTo(s * 0.38f, s * 0.62f);
                c.drawPath(p, paint);
                break;
            case PALETTE_BRUSH:
                p.setFillType(Path.FillType.EVEN_ODD);
                p.addCircle(-s * 0.1f, s * 0.08f, s * 0.7f, Path.Direction.CW);
                p.addCircle(-s * 0.36f, -s * 0.18f, s * 0.11f, Path.Direction.CW);
                p.addCircle(s * 0.06f, -s * 0.3f, s * 0.1f, Path.Direction.CW);
                p.addCircle(-s * 0.48f, s * 0.22f, s * 0.1f, Path.Direction.CW);
                p.addCircle(s * 0.08f, s * 0.46f, s * 0.1f, Path.Direction.CW);
                c.drawPath(p, paint);
                p.reset();
                p.moveTo(s * 0.18f, -s * 0.02f);
                p.lineTo(s * 0.72f, -s * 0.72f);
                p.lineTo(s * 0.84f, -s * 0.6f);
                p.lineTo(s * 0.3f, s * 0.1f);
                p.close();
                c.drawPath(p, paint);
                p.reset();
                p.moveTo(s * 0.02f, s * 0.02f);
                p.quadTo(s * 0.34f, s * 0.3f, s * 0.16f, s * 0.52f);
                p.quadTo(-s * 0.08f, s * 0.52f, s * 0.02f, s * 0.02f);
                p.close();
                c.drawPath(p, paint);
                break;
            case PAINT:
                // Paint bucket: a tilted cup with a drip.
                p.moveTo(-s * 0.55f, -s * 0.3f);
                p.lineTo(s * 0.35f, -s * 0.3f);
                p.lineTo(s * 0.12f, s * 0.42f);
                p.lineTo(-s * 0.32f, s * 0.42f);
                p.close();
                c.drawPath(p, paint);
                p.reset();
                p.moveTo(-s * 0.62f, -s * 0.42f);
                p.lineTo(-s * 0.18f, -s * 0.78f);
                p.lineTo(s * 0.48f, -s * 0.12f);
                p.lineTo(s * 0.02f, -s * 0.24f);
                p.close();
                c.drawPath(p, paint);
                c.drawCircle(s * 0.5f, s * 0.58f, s * 0.16f, paint);
                break;
            default:
                c.drawCircle(0, 0, s * 0.7f, paint);
        }
        c.restore();
    }
}
