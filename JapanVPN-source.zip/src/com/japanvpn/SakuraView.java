package com.japanvpn.v;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Sakura-petal intro animation shown when the app starts. */
final class SakuraView extends View {
    interface OnFinish { void onFinish(); }

    private static final class Petal {
        float x, y, size, speed, drift, rot, spin;
        int color;
        float alpha;
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Petal[] petals = new Petal[46];
    private final Bitmap branch;
    private final OnFinish listener;
    private long start;
    private long last;
    private boolean done;
    private float density;

    SakuraView(Context c, Bitmap branch, OnFinish listener) {
        super(c);
        this.branch = branch;
        this.listener = listener;
        this.density = getResources().getDisplayMetrics().density;
        int[] colors = {0xFFFF7EA8, 0xFFFFB3C6, 0xFFFF5C8A, 0xFFF06292};
        for (int i = 0; i < petals.length; i++) {
            Petal p = new Petal();
            p.x = (float) Math.random();
            p.y = (float) Math.random();
            p.size = 6 + (float) Math.random() * 12;
            p.speed = 0.10f + (float) Math.random() * 0.22f;
            p.drift = (float) (Math.random() - 0.5) * 0.06f;
            p.rot = (float) (Math.random() * 360);
            p.spin = (float) (Math.random() - 0.5) * 90;
            p.color = colors[i % colors.length];
            p.alpha = 0.55f + (float) Math.random() * 0.45f;
            petals[i] = p;
        }
        setBackgroundColor(Color.TRANSPARENT);
    }

    void play() {
        start = System.currentTimeMillis();
        last = start;
        setVisibility(VISIBLE);
        post(new Runnable() {
            @Override public void run() {
                if (!done) {
                    invalidate();
                    postDelayed(this, 28);
                }
            }
        });
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        long now = System.currentTimeMillis();
        float elapsed = now - start;
        float dt = Math.min(60, now - last);
        last = now;

        float fade = elapsed < 2800 ? 1f : Math.max(0f, 1f - (elapsed - 2800) / 600f);
        if (fade <= 0f) {
            finish();
            return;
        }

        int w = getWidth();
        int h = getHeight();

        // Branch from the new logo, drifting gently in the background.
        if (branch != null) {
            paint.setAlpha((int) (70 * fade));
            int bw = (int) (w * 0.85f);
            int bh = bw;
            c.drawBitmap(branch, null,
                    new android.graphics.Rect(w - bw, -bh / 5, w + bw / 6, bh - bh / 5), paint);
            paint.setAlpha(255);
        }

        for (Petal p : petals) {
            p.y += p.speed * dt / 1000f;
            p.x += p.drift * dt / 1000f;
            p.rot += p.spin * dt / 1000f;
            if (p.y > 1.08f) {
                p.y = -0.08f;
                p.x = (float) Math.random();
            }
            if (p.x < -0.1f) p.x = 1.05f;
            if (p.x > 1.1f) p.x = -0.05f;

            float px = p.x * w;
            float py = p.y * h;
            float size = p.size * density;
            paint.setColor(p.color);
            paint.setAlpha((int) (255 * p.alpha * fade));
            c.save();
            c.translate(px, py);
            c.rotate(p.rot);
            Path path = new Path();
            path.moveTo(0, -size);
            path.quadTo(size * 0.85f, -size * 0.25f, 0, size);
            path.quadTo(-size * 0.85f, -size * 0.25f, 0, -size);
            c.drawPath(path, paint);
            c.restore();
        }
        paint.setAlpha(255);
    }

    private void finish() {
        if (done) return;
        done = true;
        setVisibility(GONE);
        if (listener != null) listener.onFinish();
    }
}
