package com.japanvpn.v;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.amnezia.awg.GoBackend;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final int REQ_VPN = 42;
    private static final int REQ_IMPORT = 7;
    private static final String OLD_CONFIG_DIR = "/storage/emulated/0/Download/exteraGram";

    private final List<Config> configs = new ArrayList<Config>();
    private final Map<String, String> displayNames = new HashMap<String, String>();
    private Config selected;
    private volatile int handle = -1;
    private volatile boolean connected;
    private volatile boolean polling;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private SharedPreferences prefs;
    private int accent;
    private int accentLight;
    private int accentDark;

    private FrameLayout root;
    private View homeView;
    private View settingsView;
    private TextView statusText;
    private TextView captionText;
    private TextView configNameText;
    private TextView powerText;
    private IconView powerIcon;
    private View statusDot;
    private ConnectView connectView;
    private LinearLayout serverList;
    private LinearLayout serversAnchor;
    private ScrollView homeScroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        getWindow().getDecorView().setFitsSystemWindows(false);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 44);
        }
        applyLanguage();
        prefs = ThemeHelper.prefs(this);
        loadTheme();
        getWindow().setBackgroundDrawable(new ColorDrawable(ThemeHelper.surface(accent)));
        getWindow().setStatusBarColor(ThemeHelper.surface(accent));
        getWindow().setNavigationBarColor(ThemeHelper.surface(accent));
        loadDisplayNames();
        migrateOldConfigs();
        buildUi();
        refreshConfigs();
        if (getIntent() != null && getIntent().getBooleanExtra("auto_connect", false)) {
            ui.postDelayed(new Runnable() {
                @Override public void run() { connect(); }
            }, 700);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("auto_connect", false)) {
            ui.postDelayed(new Runnable() {
                @Override public void run() { connect(); }
            }, 300);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handle = VpnController.handle;
        connected = VpnController.connected;
        refreshConfigs();
        updateUi();
    }

    // ------------------------------------------------------------- theme ---
    private void applyLanguage() {
        String lang = ThemeHelper.lang(this);
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = getResources().getConfiguration();
        config.setLocale(locale);
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    private void loadTheme() {
        accent = ThemeHelper.accent(this);
        accentLight = ThemeHelper.light(accent);
        accentDark = ThemeHelper.darker(accent);
    }

    // --------------------------------------------------------------- UI ---
    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackground(ThemeHelper.wallpaperDrawable(this));

        int statusId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int statusH = statusId > 0 ? getResources().getDimensionPixelSize(statusId) : 0;

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        root.addView(shell, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        homeScroll = new ScrollView(this);
        homeScroll.setFillViewport(true);
        homeView = buildHome();
        homeScroll.addView(homeView, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.MATCH_PARENT));
        shell.addView(homeScroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                0, 1f));

        settingsView = buildSettings();
        shell.addView(settingsView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                0, 1f));
        settingsView.setVisibility(View.GONE);

        shell.addView(buildNav(), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        int screenH = getResources().getDisplayMetrics().heightPixels;
        FrameLayout.LayoutParams rootParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, screenH + statusH);
        rootParams.topMargin = -statusH;
        root.setLayoutParams(rootParams);
        setContentView(root);
        updateUi();
    }

    private View buildHome() {
        int pad = dp(18);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        content.setPadding(pad, dp(16), pad, dp(26));

        // Header -----------------------------------------------------------
        LinearLayout header = row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(12));
        TextView brand = text(getString(R.string.app_name), 22, true, accentLight);
        header.addView(brand, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView power = text(getString(R.string.power_off), 15, true, Color.WHITE);
        power.setGravity(Gravity.CENTER);
        power.setPadding(dp(18), dp(12), dp(18), dp(12));
        power.setBackground(roundFill(cardColor(), 20));
        powerText = power;
        power.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleVpn(); }
        });
        header.addView(power);
        content.addView(header);

        // Main card --------------------------------------------------------
        LinearLayout card = card();
        Bitmap brandLogo = BitmapFactory.decodeResource(getResources(), R.drawable.logo);
        if (brandLogo != null) {
            ImageView logoView = new ImageView(this);
            logoView.setImageBitmap(Bitmap.createScaledBitmap(brandLogo, dp(96), dp(96), true));
            LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(96), dp(96));
            logoParams.gravity = Gravity.CENTER;
            logoParams.bottomMargin = dp(4);
            card.addView(logoView, logoParams);
        }
        LinearLayout statusRow = row();
        statusRow.setGravity(Gravity.CENTER);
        statusDot = new View(this);
        statusDot.setVisibility(View.GONE);
        statusDot.setBackground(dot(muteColor()));
        LinearLayout.LayoutParams sd = new LinearLayout.LayoutParams(dp(9), dp(9));
        sd.rightMargin = dp(8);
        statusRow.addView(statusDot, sd);
        statusText = text(getString(R.string.status_stopped), 14, false, "#C8BAC4");
        statusRow.addView(statusText);
        card.addView(statusRow);

        connectView = new ConnectView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(240), dp(240));
        cp.gravity = Gravity.CENTER;
        cp.topMargin = dp(18);
        cp.bottomMargin = dp(10);
        connectView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleVpn(); }
        });
        card.addView(connectView, cp);
        captionText = text(getString(R.string.caption_direct), 13, false, "#B5A6B0");
        captionText.setGravity(Gravity.CENTER);
        card.addView(captionText);

        LinearLayout picker = row();
        picker.setGravity(Gravity.CENTER);
        picker.setPadding(0, dp(14), 0, 0);
        IconView prev = new IconView(this, IconView.BACK, accentLight, 20);
        prev.setPadding(dp(10), dp(10), dp(10), dp(10));
        prev.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { cycleConfig(-1); }
        });
        picker.addView(prev, new LinearLayout.LayoutParams(dp(44), dp(44)));
        configNameText = text("", 15, true, Color.WHITE);
        configNameText.setGravity(Gravity.CENTER);
        configNameText.setPadding(dp(12), 0, dp(12), 0);
        picker.addView(configNameText, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        IconView next = new IconView(this, IconView.BACK, accentLight, 20);
        next.setRotation(180);
        next.setPadding(dp(10), dp(10), dp(10), dp(10));
        next.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { cycleConfig(1); }
        });
        picker.addView(next, new LinearLayout.LayoutParams(dp(44), dp(44)));
        card.addView(picker);
        content.addView(card);

        return content;
    }

    private View buildNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(ThemeHelper.surface(accent));
        nav.setPadding(0, dp(12), 0, dp(24));
        addNav(nav, IconView.HOME, R.string.tab_home, new View.OnClickListener() {
            @Override public void onClick(View v) {
                showHome(true);
                homeScroll.fullScroll(View.FOCUS_UP);
            }
        });
        addNav(nav, IconView.SETTINGS, R.string.tab_settings, new View.OnClickListener() {
            @Override public void onClick(View v) { showHome(false); }
        });
        return nav;
    }

    private void addNav(LinearLayout nav, int icon, int labelRes, View.OnClickListener click) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        IconView iv = new IconView(this, icon, muteColor(), 24);
        TextView tv = text(getString(labelRes), 12, false, muteColor());
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(6), 0, 0);
        item.addView(iv);
        item.addView(tv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        item.setOnClickListener(click);
        nav.addView(item);
    }

    private void showHome(boolean home) {
        homeScroll.setVisibility(home ? View.VISIBLE : View.GONE);
        settingsView.setVisibility(home ? View.GONE : View.VISIBLE);
    }

    // --------------------------------------------------------- settings ---
    private View buildSettings() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        content.setPadding(dp(18), dp(16), dp(18), dp(26));

        // Appearance -------------------------------------------------------
        LinearLayout look = settingsCard(IconView.PALETTE_BRUSH, R.string.settings_appearance);
        look.addView(sectionLabel(getString(R.string.settings_color)));
        LinearLayout colors = row();
        colors.setPadding(0, dp(10), 0, dp(6));
        for (int i = 0; i < ThemeHelper.ACCENTS.length; i++) {
            final int color = ThemeHelper.ACCENTS[i];
            FrameLayout swatch = new FrameLayout(this);
            swatch.setBackground(circle(color, color == accent));
            if (color == accent) {
                IconView check = new IconView(this, IconView.CHECK, Color.WHITE, 22);
                swatch.addView(check, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
            }
            LinearLayout.LayoutParams sw = new LinearLayout.LayoutParams(dp(46), dp(46));
            sw.rightMargin = dp(12);
            final int index = i;
            swatch.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    prefs.edit().putInt("accent", ThemeHelper.ACCENTS[index]).apply();
                    recreate();
                }
            });
            colors.addView(swatch, sw);
        }
        look.addView(colors);

        content.addView(look);

        // Language ---------------------------------------------------------
        LinearLayout langCard = settingsCard(IconView.LANGUAGE, R.string.settings_language);
        LinearLayout langs = row();
        langs.setPadding(0, dp(8), 0, dp(2));
        final String[] langCodes = {"ru", "en"};
        final int[] langNames = {R.string.lang_ru, R.string.lang_en};
        for (int i = 0; i < langCodes.length; i++) {
            final String code = langCodes[i];
            TextView b = text(getString(langNames[i]), 13, true,
                    code.equals(ThemeHelper.lang(this)) ? Color.WHITE : Color.parseColor("#BFAEB9"));
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(12), dp(9), dp(12), dp(9));
            b.setBackground(roundFill(code.equals(ThemeHelper.lang(this)) ? accent : cardColor(), 16));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            bp.rightMargin = i < langCodes.length - 1 ? dp(8) : 0;
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    prefs.edit().putString("lang", code).apply();
                    recreate();
                }
            });
            langs.addView(b, bp);
        }
        langCard.addView(langs);
        content.addView(langCard);

        // Configs ----------------------------------------------------------
        LinearLayout cfgCard = settingsCard(IconView.FOLDER, R.string.settings_configs);
        TextView upload = text(getString(R.string.btn_upload), 14, true, Color.parseColor("#2A1620"));
        upload.setGravity(Gravity.CENTER);
        upload.setPadding(dp(12), dp(12), dp(12), dp(12));
        upload.setBackground(roundFill(accentLight, 16));
        upload.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { importConfig(); }
        });
        cfgCard.addView(upload);
        TextView hint = text(getString(R.string.empty_hint), 11, false, "#9E8F99");
        hint.setPadding(0, dp(10), 0, 0);
        cfgCard.addView(hint);

        TextView remove = text(getString(R.string.delete_selected), 14, true, Color.WHITE);
        remove.setGravity(Gravity.CENTER);
        remove.setPadding(dp(12), dp(12), dp(12), dp(12));
        remove.setBackground(roundFill(ThemeHelper.darker(Color.parseColor("#E53935")), 16));
        remove.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showDeleteMenu(); }
        });
        LinearLayout.LayoutParams rm = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rm.topMargin = dp(12);
        cfgCard.addView(remove, rm);
        content.addView(cfgCard);

        // Version ----------------------------------------------------------
        TextView version = text(getString(R.string.version), 12, false, "#9E8F99");
        version.setGravity(Gravity.CENTER);
        version.setPadding(0, dp(18), 0, dp(4));
        content.addView(version);

        scroll.addView(content, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.MATCH_PARENT));
        return scroll;
    }

    private LinearLayout settingsCard(int icon, int titleRes) {
        LinearLayout card = card();
        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        IconView iv = new IconView(this, icon, accentLight, 20);
        head.addView(iv);
        TextView t = text(getString(titleRes), 15, true, Color.WHITE);
        t.setPadding(dp(10), 0, 0, 0);
        head.addView(t);
        card.addView(head);
        return card;
    }

    private TextView sectionLabel(String value) {
        TextView tv = text(value, 12, true, "#A99AA4");
        tv.setPadding(0, dp(16), 0, 0);
        return tv;
    }

    // ------------------------------------------------------------ helpers ---
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(18), dp(16), dp(18));
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{ThemeHelper.surfaceAlt(accent), ThemeHelper.surface(accent)});
        d.setCornerRadius(dp(20));
        d.setAlpha(235);
        l.setBackground(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(16);
        l.setLayoutParams(lp);
        return l;
    }

    private TextView text(String value, int sizeSp, boolean bold, String color) {
        return text(value, sizeSp, bold, Color.parseColor(color));
    }

    private TextView text(String value, int sizeSp, boolean bold, int color) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sizeSp + 2);
        tv.setTextColor(color);
        tv.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return tv;
    }

    private static GradientDrawable roundFill(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp);
        return d;
    }

    private static GradientDrawable dot(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    private static GradientDrawable outlineBox(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(12f);
        d.setStroke(3, color);
        d.setColor(Color.TRANSPARENT);
        return d;
    }

    private static GradientDrawable circle(int color, boolean selected) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(26f);
        d.setColor(color);
        if (selected) {
            d.setStroke(4, Color.WHITE);
        }
        return d;
    }

    private int cardColor() {
        return ThemeHelper.surface(accent);
    }

    private int muteColor() {
        return Color.parseColor("#C6B6C0");
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------ configs ---
    private File configDir() {
        return new File(getFilesDir(), "configs");
    }

    private void loadDisplayNames() {
        displayNames.clear();
        for (Map.Entry<String, ?> e : prefs.getAll().entrySet()) {
            if (e.getKey().startsWith("name_") && e.getValue() instanceof String) {
                displayNames.put(e.getKey().substring(5), (String) e.getValue());
            }
        }
    }

    private String displayName(Config c) {
        String custom = displayNames.get(c.file.getName());
        return custom != null && custom.length() > 0 ? custom : c.shortName();
    }

    private void migrateOldConfigs() {
        if (prefs.getBoolean("migrated", false)) return;
        prefs.edit().putBoolean("migrated", true).apply();
        File old = new File(OLD_CONFIG_DIR);
        File[] files = old.listFiles();
        if (files == null) return;
        File dir = configDir();
        if (!dir.exists()) dir.mkdirs();
        for (File f : files) {
            if (!f.getName().toLowerCase(Locale.ENGLISH).endsWith(".conf")) continue;
            try {
                InputStream in = new FileInputStream(f);
                OutputStream out = new FileOutputStream(new File(dir, f.getName()));
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                out.close();
            } catch (Exception ignored) { }
        }
    }

    private void refreshConfigs() {
        new Thread(new Runnable() {
            @Override public void run() {
                final List<Config> found = new ArrayList<Config>();
                File[] files = configDir().listFiles();
                if (files != null) {
                    Arrays.sort(files, new Comparator<File>() {
                        @Override public int compare(File a, File b) {
                            return a.getName().compareToIgnoreCase(b.getName());
                        }
                    });
                    for (File f : files) {
                        if (!f.getName().toLowerCase(Locale.ENGLISH).endsWith(".conf")) continue;
                        try { found.add(Config.parse(f)); } catch (Exception ignored) { }
                    }
                }
                ui.post(new Runnable() {
                    @Override public void run() {
                        configs.clear();
                        configs.addAll(found);
                        if (selected == null && !configs.isEmpty()) selected = configs.get(0);
                        VpnController.selected = selected;
                        if (selected != null) {
                            boolean still = false;
                            for (Config c : configs) if (c.file.equals(selected.file)) still = true;
                            if (!still) selected = configs.isEmpty() ? null : configs.get(0);
                        }
                        renderServers();
                        updateUi();
                    }
                });
            }
        }, "japan-scan").start();
    }

    private void renderServers() {
        if (serverList == null) return;
        serverList.removeAllViews();
        if (configs.isEmpty()) {
            TextView empty = text(getString(R.string.empty_title), 16, true, Color.WHITE);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(16), 0, dp(6));
            serverList.addView(empty);
            TextView hint = text(getString(R.string.empty_hint), 12, false, "#A99AA4");
            hint.setGravity(Gravity.CENTER);
            hint.setPadding(0, 0, 0, dp(8));
            serverList.addView(hint);
            return;
        }
        for (final Config c : configs) {
            final boolean isSelected = selected != null && selected.file.equals(c.file);
            LinearLayout item = row();
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(10), dp(11), dp(10), dp(11));
            item.setBackground(roundFill(isSelected ? ThemeHelper.darker(accent) : ThemeHelper.surface(accent), 12));

            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            TextView name = text(displayName(c), 14, true, isSelected ? Color.WHITE : Color.parseColor("#E6D8E0"));
            info.addView(name);
            TextView sub = text(c.endpointHost == null ? "AmneziaWG" : c.endpointHost,
                    11, false, isSelected ? accentLight : Color.parseColor("#9E8F99"));
            info.addView(sub);
            item.addView(info, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            if (isSelected) {
                item.addView(new IconView(this, IconView.CHECK, accentLight, 16));
            }
            IconView pencil = new IconView(this, IconView.PENCIL, muteColor(), 17);
            pencil.setPadding(dp(6), 0, dp(6), 0);
            pencil.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { renameConfig(c); }
            });
            item.addView(pencil);
            IconView trash = new IconView(this, IconView.TRASH, muteColor(), 17);
            trash.setPadding(dp(6), 0, 0, 0);
            trash.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { deleteConfig(c); }
            });
            item.addView(trash);

            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { selected = c; renderServers(); updateUi(); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(8);
            serverList.addView(item, lp);
        }
    }

    private void renameConfig(final Config c) {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(displayName(c));
        input.setSelection(input.getText().length());
        input.setPadding(dp(16), dp(12), dp(16), dp(12));
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.rename))
                .setView(input)
                .setPositiveButton(getString(R.string.save), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String value = input.getText().toString().trim();
                        if (value.length() == 0) return;
                        value = value.replaceAll("[/\\\\:*?\"<>|]", "_");
                        String key = "name_" + c.file.getName();
                        prefs.edit().putString(key, value).apply();
                        displayNames.put(c.file.getName(), value);
                        File renamed = new File(configDir(), value + ".conf");
                        if (!renamed.exists() && c.file.renameTo(renamed)) {
                            displayNames.remove(c.file.getName());
                            c.file = renamed;
                            prefs.edit().remove(key).putString("name_" + renamed.getName(), value).apply();
                            displayNames.put(renamed.getName(), value);
                        }
                        renderServers();
                        updateUi();
                        toast(getString(R.string.toast_renamed));
                    }
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void showDeleteMenu() {
        if (configs.isEmpty()) {
            toast(getString(R.string.empty_title));
            return;
        }
        final AlertDialog[] holder = new AlertDialog[1];

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable shell = new GradientDrawable();
        shell.setColor(ThemeHelper.surfaceAlt(accent));
        shell.setCornerRadius(dp(24));
        shell.setStroke(2, accent);
        box.setBackground(shell);
        box.setPadding(dp(20), dp(20), dp(20), dp(18));

        TextView title = text(getString(R.string.delete_selected), 20, true, accentLight);
        title.setPadding(0, 0, 0, dp(4));
        box.addView(title);
        TextView sub = text(getString(R.string.delete_hint), 13, false, "#BCAEB8");
        sub.setPadding(0, 0, 0, dp(14));
        box.addView(sub);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(roundFill(ThemeHelper.surface(accent), 16));
        list.setPadding(dp(10), dp(10), dp(10), dp(4));
        final List<CheckBox> boxes = new ArrayList<CheckBox>();
        for (Config c : configs) {
            CheckBox cb = new CheckBox(this);
            cb.setText(displayName(c) + "\n" +
                    (c.endpointHost == null ? "AmneziaWG" : c.endpointHost));
            cb.setTextColor(Color.WHITE);
            cb.setTextSize(14);
            cb.setButtonTintList(ColorStateList.valueOf(accent));
            cb.setPadding(dp(12), dp(10), dp(8), dp(10));
            GradientDrawable itemBg = new GradientDrawable();
            itemBg.setColor(ThemeHelper.surface(accent));
            itemBg.setCornerRadius(dp(12));
            itemBg.setStroke(2, accent);
            cb.setBackground(itemBg);
            boxes.add(cb);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(8);
            list.addView(cb, lp);
        }
        ScrollView scroller = new ScrollView(this);
        scroller.addView(list, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        box.addView(scroller, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                configs.size() > 3 ? dp(300) : LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout actions = row();
        actions.setGravity(Gravity.END);
        actions.setPadding(0, dp(16), 0, 0);
        TextView cancel = text(getString(R.string.cancel), 14, true, muteColor());
        cancel.setPadding(dp(16), dp(10), dp(16), dp(10));
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { holder[0].dismiss(); }
        });
        TextView remove = text(getString(R.string.delete), 14, true, Color.WHITE);
        remove.setBackground(roundFill(ThemeHelper.darker(Color.parseColor("#E53935")), 14));
        remove.setPadding(dp(20), dp(10), dp(20), dp(10));
        remove.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int count = 0;
                for (int i = 0; i < boxes.size(); i++) {
                    if (!boxes.get(i).isChecked()) continue;
                    Config c = configs.get(i);
                    c.file.delete();
                    prefs.edit().remove("name_" + c.file.getName()).apply();
                    if (selected == c) selected = null;
                    count++;
                }
                if (count > 0) {
                    refreshConfigs();
                    toast(getString(R.string.toast_deleted));
                }
                holder[0].dismiss();
            }
        });
        actions.addView(cancel);
        actions.addView(remove);
        box.addView(actions);

        holder[0] = new AlertDialog.Builder(this).setView(box).create();
        holder[0].getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        holder[0].show();
    }

    private void deleteConfig(final Config c) {
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.delete))
                .setMessage(displayName(c))
                .setPositiveButton(getString(R.string.delete), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        c.file.delete();
                        prefs.edit().remove("name_" + c.file.getName()).apply();
                        if (selected == c) selected = null;
                        refreshConfigs();
                        toast(getString(R.string.toast_deleted));
                    }
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void importConfig() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        try {
            startActivityForResult(intent, REQ_IMPORT);
        } catch (Exception e) {
            toast(getString(R.string.toast_upload_fail));
        }
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_VPN && result == RESULT_OK) {
            startVpn();
        } else if (request == REQ_IMPORT && result == RESULT_OK && data != null && data.getData() != null) {
            copyImported(data.getData());
        }
    }

    private void copyImported(Uri uri) {
        String display = "config.conf";
        ContentResolver cr = getContentResolver();
        Cursor cursor = cr.query(uri, null, null, null, null);
        if (cursor != null) {
            try {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0 && cursor.moveToFirst()) display = cursor.getString(idx);
            } finally {
                cursor.close();
            }
        }
        if (!display.toLowerCase(Locale.ENGLISH).endsWith(".conf")) display += ".conf";
        File dir = configDir();
        if (!dir.exists()) dir.mkdirs();
        try {
            InputStream in = cr.openInputStream(uri);
            OutputStream out = new FileOutputStream(new File(dir, display));
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            out.close();
            toast(getString(R.string.toast_uploaded));
            refreshConfigs();
        } catch (Exception e) {
            toast(getString(R.string.toast_upload_fail));
        }
    }

    private void cycleConfig(int direction) {
        if (configs.isEmpty()) return;
        int i = configs.indexOf(selected);
        if (i < 0) i = 0;
        else i = (i + direction + configs.size()) % configs.size();
        selected = configs.get(i);
        VpnController.selected = selected;
        updateUi();
    }

    // --------------------------------------------------------------- vpn ---
    private void toggleVpn() {
        if (handle >= 0) disconnect();
        else connect();
    }

    private void connect() {
        if (selected == null) {
            toast(getString(R.string.toast_no_server));
            return;
        }
        Intent intent;
        try {
            intent = VpnService.prepare(this);
        } catch (Exception e) {
            toast(getString(R.string.toast_connect_error, e.getMessage()));
            return;
        }
        if (intent != null) {
            startActivityForResult(intent, REQ_VPN);
            return;
        }
        startVpn();
    }

    private void startVpn() {
        final Config cfg = selected;
        if (cfg == null) return;
        connected = false;
        statusText.setText(getString(R.string.status_connecting));
        updateUi();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    Intent si = new Intent(MainActivity.this, VpnService.class);
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(si);
                    else startService(si);
                    VpnService svc = null;
                    for (int i = 0; i < 50; i++) {
                        svc = VpnService.instance;
                        if (svc != null) break;
                        Thread.sleep(100);
                    }
                    if (svc == null) throw new Exception("VPN service");
                    VpnService.Builder b = svc.newBuilder();
                    svc.prepareBuilder(b);
                    for (String[] a : cfg.addresses) b.addAddress(a[0], Integer.parseInt(a[1]));
                    for (String d : cfg.dns) b.addDnsServer(d);
                    for (String[] n : cfg.allowedIps) b.addRoute(n[0], Integer.parseInt(n[1]));
                    b.setMtu(cfg.mtu);
                    ParcelFileDescriptor tun = b.establish();
                    if (tun == null) throw new Exception("TUN");
                    int h = GoBackend.awgTurnOn("japanvpn", tun.detachFd(), cfg.settings);
                    if (h < 0) throw new Exception("AmneziaWG " + h);
                    handle = h;
                    VpnController.sync(h, true);
                    VpnController.persist(MainActivity.this, h, true);
                    svc.protectSocket(GoBackend.awgGetSocketV4(h));
                    svc.protectSocket(GoBackend.awgGetSocketV6(h));
                    ui.post(new Runnable() {
                        @Override public void run() {
                            connected = true;
                            Notifications.show(MainActivity.this);
                            updateUi();
                            startPolling();
                        }
                    });
                } catch (final Exception e) {
                    ui.post(new Runnable() {
                        @Override public void run() {
                            handle = -1;
                            connected = false;
                            VpnController.sync(-1, false);
                            VpnController.persist(MainActivity.this, -1, false);
                            updateUi();
                            toast(getString(R.string.toast_connect_error, String.valueOf(e.getMessage())));
                        }
                    });
                }
            }
        }, "japan-connect").start();
    }

    private void disconnect() {
        int h = handle;
        handle = -1;
        connected = false;
        VpnController.sync(-1, false);
        VpnController.persist(this, -1, false);
        Notifications.hide(this);
        if (h >= 0) try { GoBackend.awgTurnOff(h); } catch (Exception ignored) { }
        try { stopService(new Intent(this, VpnService.class)); } catch (Exception ignored) { }
        updateUi();
    }

    private void startPolling() {
        if (polling) return;
        polling = true;
        new Thread(new Runnable() {
            @Override public void run() {
                while (polling && handle >= 0) {
                    final int h = handle;
                    String dump = null;
                    try { dump = GoBackend.awgGetConfig(h); } catch (Exception ignored) { }
                    final String configDump = dump;
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (handle < 0) return;
                            boolean handshake = false;
                            if (configDump != null) {
                                for (String line : configDump.split("\n")) {
                                    if (line.startsWith("last_handshake_time_sec=")) {
                                        try {
                                            handshake = Long.parseLong(line.substring(24)) > 0;
                                        } catch (Exception ignored) { }
                                    }
                                }
                            }
                            statusText.setText(handshake ? getString(R.string.status_connected)
                                    : getString(R.string.status_waiting));
                            statusDot.setBackground(dot(handshake ? accentLight : muteColor()));
                        }
                    });
                    try { Thread.sleep(1500); } catch (InterruptedException e) { break; }
                }
                polling = false;
            }
        }, "japan-status").start();
    }

    private void updateUi() {
        boolean on = handle >= 0;
        connectView.setConnected(on);
        if (configNameText != null) {
            configNameText.setText(selected == null ? getString(R.string.empty_title)
                    : displayName(selected));
        }
        powerText.setText(getString(on ? R.string.power_on : R.string.power_off));
        powerText.setTextColor(Color.WHITE);
        powerText.setBackground(roundFill(on ? accent : cardColor(), 20));
        if (powerIcon != null) powerIcon.setColor(on ? accentLight : muteColor());
        if (!on) {
            statusText.setText(getString(R.string.status_stopped));
            captionText.setText(selected == null ? getString(R.string.caption_direct)
                    : getString(R.string.caption_server, displayName(selected)));
            statusDot.setBackground(dot(muteColor()));
        } else {
            captionText.setText(getString(R.string.caption_connected,
                    selected == null ? "" : displayName(selected)));
        }
        connectView.invalidate();
    }

    @Override
    protected void onDestroy() {
        disconnect();
        super.onDestroy();
    }

    // -------------------------------------------------------- connect btn ---
    private final class ConnectView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean on;

        ConnectView(Activity a) {
            super(a);
            textPaint.setColor(Color.WHITE);
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        }

        void setConnected(boolean value) {
            on = value;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(getWidth(), getHeight()) / 2f - dp(4);

            paint.setShader(new android.graphics.LinearGradient(0, cy - r, 0, cy + r,
                    ThemeHelper.darker(accent), ThemeHelper.deep(accent), Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, paint);
            paint.setShader(null);

            paint.setColor(ThemeHelper.light(accent));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setAlpha(90);
            c.drawCircle(cx, cy, r - dp(10), paint);
            paint.setAlpha(255);
            paint.setStyle(Paint.Style.FILL);

            float gy = cy - dp(6);
            paint.setColor(Color.WHITE);
            if (on) {
                c.drawRect(cx - dp(12), gy - dp(12), cx - dp(4), gy + dp(12), paint);
                c.drawRect(cx + dp(4), gy - dp(12), cx + dp(12), gy + dp(12), paint);
            } else {
                android.graphics.Path p = new android.graphics.Path();
                p.moveTo(cx - dp(7), gy - dp(13));
                p.lineTo(cx + dp(15), gy);
                p.lineTo(cx - dp(7), gy + dp(13));
                p.close();
                c.drawPath(p, paint);
            }

            textPaint.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 16,
                    getResources().getDisplayMetrics()));
            c.drawText(getString(on ? R.string.btn_disconnect : R.string.btn_connect),
                    cx, cy + r * 0.62f, textPaint);
        }
    }
}
