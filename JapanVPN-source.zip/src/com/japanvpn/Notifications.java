package com.japanvpn.v;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/** One silent notification with a disconnect button — no repeats, no sound. */
public final class Notifications {
    private static final String CHANNEL = "japanvpn_status";
    private static final int ID = 101;

    private Notifications() { }

    public static void show(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "JapanVPN",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Silent VPN status");
            ch.setSound(null, null);
            ch.enableVibration(false);
            nm.createNotificationChannel(ch);
        }

        Intent open = new Intent(c, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(c, 3, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(c, VpnService.class);
        stop.setAction("stop");
        PendingIntent stopPi = PendingIntent.getService(c, 4, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        Notification n = b
                .setSmallIcon(R.drawable.ic_white)
                .setContentTitle(c.getString(R.string.app_name))
                .setContentText(c.getString(R.string.notification_text))
                .setStyle(new Notification.BigTextStyle()
                        .bigText(c.getString(R.string.notification_text)))
                .setContentIntent(openPi)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .setSound(null)
                .addAction(R.drawable.ic_white,
                        c.getString(R.string.btn_disconnect), stopPi)
                .build();
        nm.notify(ID, n);
    }

    public static void hide(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(ID);
    }
}
