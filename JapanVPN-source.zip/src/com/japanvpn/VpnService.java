package com.japanvpn.v;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Android VpnService that owns the tun interface created for AmneziaWG. */
public final class VpnService extends android.net.VpnService {
    public static volatile VpnService instance;
    private static final String CHANNEL = "japanvpn";

    public Builder newBuilder() {
        return new Builder();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        startAsForeground();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        instance = this;
        if (intent != null && "stop".equals(intent.getAction())) {
            VpnController.stop(this);
            stopSelf();
            return START_NOT_STICKY;
        }
        startAsForeground();
        return START_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "JapanVPN",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Silent VPN service notification");
            ch.setSound(null, null);
            ch.enableVibration(false);
            nm.createNotificationChannel(ch);
        }

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, VpnService.class);
        stop.setAction("stop");
        PendingIntent stopPi = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        Notification notification = b
                .setSmallIcon(R.drawable.ic_white)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notification_text))
                .setContentIntent(openPi)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, getString(R.string.btn_disconnect), stopPi)
                .build();
        try {
            startForeground(100, notification);
        } catch (Exception ignored) { }
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    public boolean protectSocket(int fd) {
        return fd >= 0 && protect(fd);
    }

    public void prepareBuilder(Builder b) {
        b.setSession("JapanVPN");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) b.setMetered(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) setUnderlyingNetworks(null);
        b.setBlocking(true);
    }
}
