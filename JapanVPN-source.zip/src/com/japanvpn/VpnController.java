package com.japanvpn.v;

import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.widget.Toast;

import org.amnezia.awg.GoBackend;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Comparator;

/** Shared VPN state used by the UI, the notification and the quick settings tile. */
public final class VpnController {
    public static volatile int handle = -1;
    public static volatile boolean connected = false;
    public static volatile Config selected;

    private VpnController() { }

    private static final String PREFS = "japanvpn";

    public static void sync(int h, boolean c) {
        handle = h;
        connected = c;
    }

    public static void persist(Context c, int h, boolean on) {
        c.getSharedPreferences(PREFS, 0).edit()
                .putInt("vpn_handle", h).putBoolean("vpn_on", on).apply();
    }

    private static int loadHandle(Context c) {
        return c.getSharedPreferences(PREFS, 0).getInt("vpn_handle", -1);
    }

    public static Config firstConfig(Context c) {
        File dir = new File(c.getFilesDir(), "configs");
        File[] files = dir.listFiles();
        if (files == null) return null;
        Arrays.sort(files, new Comparator<File>() {
            @Override public int compare(File a, File b) {
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        for (File f : files) {
            if (!f.getName().toLowerCase(java.util.Locale.ENGLISH).endsWith(".conf")) continue;
            try {
                InputStream in = new FileInputStream(f);
                String text = readAll(in);
                in.close();
                return Config.parse(f);
            } catch (Exception ignored) { }
        }
        return null;
    }

    private static String readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toString("UTF-8");
    }

    public static void toggle(Context c) {
        int h = handle;
        boolean serviceAlive = com.japanvpn.v.VpnService.instance != null;
        if (h < 0 || !serviceAlive) {
            h = -1;
            handle = -1;
            connected = false;
            persist(c, -1, false);
        }
        if (h >= 0) {
            stop(c);
        } else {
            start(c, selected != null ? selected : firstConfig(c));
        }
    }

    public static void start(final Context c, final Config cfg) {
        if (cfg == null) {
            Toast.makeText(c, c.getString(R.string.toast_no_server), Toast.LENGTH_LONG).show();
            return;
        }
        connected = false;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    Intent si = new Intent(c, VpnService.class);
                    if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(si);
                    else c.startService(si);
                    com.japanvpn.v.VpnService svc = null;
                    for (int i = 0; i < 50; i++) {
                        svc = com.japanvpn.v.VpnService.instance;
                        if (svc != null) break;
                        Thread.sleep(100);
                    }
                    if (svc == null) throw new Exception("VPN service");
                    android.net.VpnService.Builder b = svc.newBuilder();
                    svc.prepareBuilder(b);
                    for (String[] a : cfg.addresses) b.addAddress(a[0], Integer.parseInt(a[1]));
                    for (String d : cfg.dns) b.addDnsServer(d);
                    for (String[] n : cfg.allowedIps) b.addRoute(n[0], Integer.parseInt(n[1]));
                    b.setMtu(cfg.mtu);
                    ParcelFileDescriptor tun = b.establish();
                    if (tun == null) throw new Exception("TUN");
                    int h = GoBackend.awgTurnOn("japanvpn", tun.detachFd(), cfg.settings);
                    if (h < 0) throw new Exception("AmneziaWG " + h);
                    sync(h, true);
                    persist(c, h, true);
                    Notifications.show(c.getApplicationContext());
                } catch (Exception e) {
                    sync(-1, false);
                }
            }
        }, "japan-tile-connect").start();
    }

    public static void stop(Context c) {
        int h = handle;
        sync(-1, false);
        persist(c, -1, false);
        Notifications.hide(c);
        if (h >= 0) {
            try { GoBackend.awgTurnOff(h); } catch (Exception ignored) { }
        }
        try { c.stopService(new Intent(c, VpnService.class)); } catch (Exception ignored) { }
    }
}
