package org.amnezia.awg;

/**
 * JNI wrapper for the official AmneziaWG userspace library (libwg-go.so).
 * The class and method names must stay exactly like this: the native library
 * resolves its JNI entry points by these names.
 */
public final class GoBackend {
    static {
        System.loadLibrary("wg-go");
    }

    public static native int awgTurnOn(String ifname, int tunFd, String settings);
    public static native void awgTurnOff(int handle);
    public static native int awgGetSocketV4(int handle);
    public static native int awgGetSocketV6(int handle);
    public static native String awgGetConfig(int handle);
    public static native String awgVersion();

    private GoBackend() {
    }
}
